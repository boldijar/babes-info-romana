#include <stdio.h>
#include <string.h>
#include "dict.h"
void init (dictionar &d)
{
d.n=0;
d.prim=0;
}
int lungime(dictionar d)
{
return (d.n);
}
void adauga(dictionar &d,char cheie1[50],char valoare1[50])
{
	element* e;
	TElement t;
	strcpy(e->cheie,cheie1);
	strcpy(e->valoare,valoare1);
	t.inf=*e;
	t.indice=lungime(d)+1;
	d.sir[lungime(d)]=t;
	d.n++;
}
void sterge(dictionar &d, char cheie1[50])
{
  if (d.prim==exista(d,cheie1)) d.prim=d.sir[d.prim].indice;
	else {
	 int p=d.prim;
	 int tmp=d.sir[p].indice;
	 while (strcmp(d.sir[tmp].inf.cheie,cheie1) !=0 ) {
		p=tmp;
		tmp=d.sir[p].indice;
		}
	 d.sir[p].indice=d.sir[tmp].indice;
	}
}
void adaugaP(dictionar &d,char cheie1[50],char valoare1[50],int poz)
{

 if (poz==1) {  element* e;
		TElement t;

		strcpy(e->cheie,cheie1);
		strcpy(e->valoare,valoare1);
		t.inf=*e;
		t.indice=d.prim;
		d.prim=lungime(d);
		d.sir[lungime(d)]=t;
		d.n++;
		}
	  else{
	int nr=1,q=d.prim;
	while(nr<poz-1) {
		q=d.sir[q].indice;
		nr++;
	       }
       int tmp=d.sir[q].indice;
       element* e;
       TElement t;
	strcpy(e->cheie,cheie1);
	strcpy(e->valoare,valoare1);
	t.inf=*e;
	t.indice=tmp;
	d.sir[lungime(d)]=t;
	d.sir[q].indice=lungime(d);
	d.n++;
	       }
}
char* extrage(dictionar d, char cheie1[50])
{
 TElement t;
 element e;
 int q=d.prim;
do {
  t=d.sir[q];
  e=t.inf;
  q=t.indice;
  if (strcmp(e.cheie,cheie1)==0) return e.valoare;
} while (!(q==-1));

}
int exista(dictionar d,char cheie1[50])
{
for (int i=0; i<lungime(d);i++)
	if (strcmp(d.sir[i].inf.cheie,cheie1)==0) return i;
	return -1;
}
int vida(dictionar d)
{
if (lungime(d)==0)return 1;
return 0;
}
void citire(dictionar &d1){
init(d1);
char c[50];
char nr[50];
int numar;
printf("Dati nr de perechi de elemente: ");
scanf("%d",&numar);
if (numar<1) printf("Introduce-ti valori! "); else
for (int i=0; i<numar; i++) {
	printf("Numele: ");
	scanf("%s",c);
	printf("Telefon: ");
	scanf("%s",nr);
	if (i==numar-1) adauga_sf(d1,c,nr);
	else adauga(d1,c,nr);
	}
}
void adauga_sf(dictionar &d, char c[50],char nr[50])
{

  element* e;
  TElement t;
  strcpy(e->cheie,c);
  strcpy(e->valoare,nr);
  t.inf=*e;
  t.indice=-1;
  d.sir[lungime(d)]=t;
  d.n++;
}
void tipar(dictionar d)
{
TElement t;
element e;
printf("\nElementele sunt:\n");
int q=d.prim;
do {
  t=d.sir[q];
  e=t.inf;
  q=t.indice;
  printf("%s ",e.cheie);
  printf("%s\n",e.valoare);
}   while (!(q==-1));
}


