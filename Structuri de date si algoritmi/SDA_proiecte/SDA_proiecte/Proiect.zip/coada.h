#ifndef Coada_H
#define Coada_H
#define maxim 100

struct Elem
{
	char v[30];
};

class Coada
{
	private:
		Elem c[maxim];
		int l;
	public:
		Coada()
		{
			l=0;
		}	
		~Coada()
		{}
 		int getLungime()
		{
			return l;
		}
		void  push(char* a)
		{
			strcpy(c[l].v,a);
			l++;
		}
		char* pop()
		{
			char aux[30];
			strcpy(aux,c[0].v);
			l--;
			for(int i=0;i<l;i++)
				c[i]=c[i+1];
			
			return aux;
		}
		char* peek()
		{
			return c[0].v;
			
		}
		int eVida()
		{
		  if(l) return 0;
		  return 1;
		}
};
#endif