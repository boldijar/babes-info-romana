#include <iostream>
#include "stiva.h"
#include "coada.h"
#include <string.h>
#include <conio.h>
#include <math.h>

using namespace std;

int eOperator(char *c)									//verifica starea caracterului c de operator
{
	return (!strcmp(c,"^") || !strcmp(c,"+") || !strcmp(c,"-") || !strcmp(c,"*") || !strcmp(c,"/"));
}

int eOperand(char *c)									//verifica starea caracterului c de operand
{
	return (!eOperator(c) && strcmp(c,"(") && strcmp(c,")") );
}



int fPrioritate(char *c)								// returneaza Prioritateritatea operatorilor
{
	if (!strcmp(c,"^"))
		return 5;
	if (!strcmp(c,"*") || !strcmp(c,"/"))
		return 4;
	if (!strcmp(c,"+") || !strcmp(c,"-"))
		return 3;
	if (!strcmp(c,"("))
		return 2;
	if (!strcmp(c,")"))
		return 1;
}

void StrToCoada(Coada &c,char *exp)
{
		int len=strlen(exp),i;
		char tmpStr[30],aux[30];
		strcpy(tmpStr,"");

		for (i=0;i<len;i++)
		{
			sprintf(aux,"%c",exp[i]);
			if(eOperand(aux))
				strcat(tmpStr,aux);
			
			if(eOperator(aux) || !strcmp(aux,")") || !strcmp(aux,"("))
			{
				if(strcmp(tmpStr,""))
					c.push(tmpStr);
				strcpy(tmpStr,"");
				c.push(aux);
			}
			if(i==len-1)
				if (strcmp(tmpStr,""))
					c.push(tmpStr);
		}
}



int InToPo(char *ins,char *pos,Coada &cc)				// converteste expresia citita
														// din forma infixata in forma postfixata
														
{
	Stiva st;
	Coada co;
	Stiva infs;
	
	StrToCoada(co,ins);
	char ent[30],ent2[30],aux[30];
	strcpy(pos,"");

	while(!co.eVida())
	{
		strcpy(ent,co.peek());

		if (eOperand(ent))
		{
			strcat(pos,ent);
			strcat(pos," ");
			cc.push(ent);
		}

		if (eOperator(ent))
		{
			if(strcmp(ent,"^"))
			{
				while(!st.goala() && (fPrioritate(ent)<=fPrioritate(st.peek())))
				{
					strcpy(ent2,st.pop());
					strcat(pos,ent2);
					strcat(pos," ");
					cc.push(ent2);
				}
			}
			else
				while(!st.goala() && (fPrioritate(ent)<fPrioritate(st.peek())))
				{
					strcpy(ent2,st.pop());
					strcat(pos,ent2);
					strcat(pos," ");
					cc.push(ent2);
				}
			st.push(ent);
		}
		if(!strcmp(ent,"("))
			st.push(ent);
		if(!strcmp(ent,")"))
		{
			while(strcmp(st.peek(),"("))
			{
				strcpy(ent2,st.pop());
				strcat(pos,ent2);
				strcat(pos," ");
				cc.push(ent2);
			}
			st.pop();
		}
		co.pop();
	}
	while(!st.goala())
	{
		if(!strcmp(st.peek(),"("))
			st.pop();
		else
		{
			strcpy(ent,st.pop());
			strcat(pos,ent);
			strcat(pos," ");
			cc.push(ent);
		}

	}
	return 1;

}

int main()
{
	char exp[200],posf[200];
	cout<<"Dati o expresie:";
	cin>>exp;
	Coada c;
	
	InToPo(exp,posf,c); 

	cout<<"Forma Postfixata : "<<posf<<endl;
	_getch();
	return 0;
}