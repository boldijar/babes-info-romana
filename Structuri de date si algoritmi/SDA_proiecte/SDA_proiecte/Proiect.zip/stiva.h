#ifndef Stiva_H
#define Stiva_H
#include "nod.h"
#include <iostream>
using namespace std;

class Stiva
{
	private:
		Nod* vf;
	public:
		Stiva()
		{
			vf=NULL;
		}
		Nod* getVf()
		{
			return vf;
		}
		void push(char* e)
		{
			Nod* nou=new Nod(e,NULL);
			if(vf==NULL)
				vf=nou;
			else
			{
				nou->setUrm(vf);
				vf=nou;
			}
		}
		char* peek()
		{
			if (vf!=NULL)
				return vf->getInfo();
			return "";
		}
		char* pop()
		{
			if (vf!=NULL)
			{
				char aux[30];
				strcpy(aux,vf->getInfo());
				Nod* p=vf;
				vf=vf->getUrm();
				delete p;
				return aux;
			}
			return "";
		}
		int goala()
		{
			return vf==NULL;
		}

		~Stiva()
		{
			Nod *p;
			while(vf)
			{
				p=vf;
				vf=vf->getUrm();
				delete p;
			}
		}
};
#endif