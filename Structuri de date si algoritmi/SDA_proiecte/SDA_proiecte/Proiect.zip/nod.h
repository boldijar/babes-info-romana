#ifndef Nod_H
#define Nod_H

class Nod
{
	private:
		Nod* urm;
		char info[30];
	public:
		Nod()
		{
			urm=0;
			strcpy(info,"");
		}
		Nod(char* e, Nod* u)
		{
			urm=u;
			strcpy(info,e);
		}
		Nod(char* e)
		{
			strcpy(info,e);
		}

		char* getInfo()
		{
		  return info;
		}
		
		Nod* getUrm()
		{
			return urm;
		}
		void setUrm(Nod* u)
		{
			urm=u;
		}
		
		void setInfo(char* e)
		{
			strcpy(info,e);
		}
};
#endif