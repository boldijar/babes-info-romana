#pragma once

#include "DomainClass.h"
//#include "DynamicList.h"
#include <vector>
class ControllerClass
{
public:
	ControllerClass(void);
    std::vector<DomainClass> getAll();
    void add(int,int,float,char*);
    void updateController(int id,int number,float amount,char* type);
    void deleteController(int nr);
    void filterAmountController(float suma,std::vector<DomainClass>  &);
    void filterTypeController(char* tip, std::vector<DomainClass>  &);
    void sortAmountController(std::vector<DomainClass>  &);
    void sortAmountControllerDesc(std::vector<DomainClass>  &);
    void sortTypeController(std::vector<DomainClass>  &);
    void sortTypeControllerDesc(std::vector<DomainClass>  &);
    int findById(int id);
    int findByType(char* tip);
	~ControllerClass(void);
};

