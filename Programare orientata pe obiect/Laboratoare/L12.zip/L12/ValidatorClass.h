#pragma once
#include "BoolValidator.h"
class ValidatorClass:BoolValidator
{
public:
	ValidatorClass(void);

    void validareId(int);
	void testValidatori();
	void validareNumar(int);
    void validareSuma(float);

    ~ValidatorClass(void);
};

