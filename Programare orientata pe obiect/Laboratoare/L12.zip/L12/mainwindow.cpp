#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<iostream>
#include<string.h>
#include<QString>
#include<QLabel>
#include<Except.h>
#include<ValidatorClass.h>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    construiesteFereastra();
    this->ctrl = ctrl;
    conectare();
    adaugaInLista();
}

void MainWindow::construiesteFereastra() {
    //fac primul Layot si pun un QListWidget pe el
    mainLayout = new QHBoxLayout();
    this->list = new QListWidget();
    mainLayout->addWidget(this->list);
   // clean = new QPushButton("&Goleste Campuri");
   // mainLayout->addWidget(this->clean);

    //fac al doilea layot si pun QLineEdit si label-uri
    dateLayout = new QFormLayout();
    mainLayout->addLayout(this->dateLayout);

    IDfield = new QLineEdit("ID");
    dateLayout->addRow(new QLabel("ID"),this->IDfield);
    nrfield = new QLineEdit("Number");
    dateLayout->addRow(new QLabel("Number"),this->nrfield);
    amtfield = new QLineEdit("Amount");
    dateLayout->addRow(new QLabel("Amount"),this->amtfield);


    dateLayout->addRow(new QLabel("Tipul cheluielii"));
    rdbwater = new QRadioButton("Water");
    rdblighting = new QRadioButton("Lighting");
    dateLayout->addRow(this->rdbwater,this->rdblighting);
    rdbheating = new QRadioButton("Heating");
    rdbgas = new QRadioButton("Gas");
    dateLayout->addRow(this->rdbheating,this->rdbgas);
    rdbothers = new QRadioButton("Others");
    dateLayout->addRow(this->rdbothers);

    //buton de adaugare

    clean = new QPushButton("&Goleste Campuri");
    dateLayout->addRow(this->clean);
    add = new QPushButton("&Add");
    dateLayout->addRow(this->add);
    update = new QPushButton("&Update");
    dateLayout->addRow(this->update);
    del = new QPushButton("&Delete");
    dateLayout->addRow(this->del);

   // //Layout 3

    filterLayout = new QFormLayout();
    mainLayout->addLayout(this->filterLayout);

    filtrAmount = new QPushButton("&Filtrare dupa suma");
    filterLayout->addRow(this->filtrAmount);

    filterType = new QPushButton("&Filtrare dupa tip");
    filterLayout->addRow(this->filterType);
    sortAmAsc = new QPushButton("&Sortare suma ascendent");
    filterLayout->addRow(this->sortAmAsc);
    sortAmDesc = new QPushButton("&Sortare suma descendent");
    filterLayout->addRow(this->sortAmDesc);
    sortTypeAsc = new QPushButton("&Sortare tip ascendent");
    filterLayout->addRow(this->sortTypeAsc);
    sortTypeDesc = new QPushButton("&Sortare tip descendent");
    filterLayout->addRow(this->sortTypeDesc);

    this->centralWidget()->setLayout(mainLayout);
}

void MainWindow::conectare(){
    QObject::connect(clean,&QPushButton::clicked,this,&MainWindow::curata);
    QObject::connect(add,&QPushButton::clicked,this,&MainWindow::butonAdaugare);
    QObject::connect(update,&QPushButton::clicked,this,&MainWindow::butonModifica);
    QObject::connect(del,&QPushButton::clicked,this,&MainWindow::butonSterge);
    QObject::connect(filtrAmount,&QPushButton::clicked,this,&MainWindow::butonFilterAmount);
    QObject::connect(filterType,&QPushButton::clicked,this,&MainWindow::butonFilterType);
    QObject::connect(sortAmAsc,&QPushButton::clicked,this,&MainWindow::butonSortAmountAsc);
    QObject::connect(sortAmDesc,&QPushButton::clicked,this,&MainWindow::butonSortAmountDesc);
    QObject::connect(sortTypeAsc,&QPushButton::clicked,this,&MainWindow::butonSortTypeAsc);
    QObject::connect(sortTypeDesc,&QPushButton::clicked,this,&MainWindow::butonSortTypeDesc);
    //QObject::connect(add,SIGNAL(clicked()), this, SLOT(butonAdaugare) );
    QObject::connect(list,&QListWidget::itemSelectionChanged,this,&MainWindow::selecteazaDinLista);    // conexiunile
}

void MainWindow::butonAdaugare() {

    QString idQString = IDfield->text();
    QString IDQString = IDfield->text();
    QString nrQString = nrfield->text();
    QString amountQString = amtfield->text();
    QString typeQString;
    if (rdbgas->isChecked())
        typeQString = rdbgas->text();
    else if(rdblighting->isChecked())
        typeQString = rdblighting->text();
    else if(rdbwater->isChecked())
        typeQString = rdbwater->text();
    else if(rdbheating->isChecked())
        typeQString = rdbheating->text();
    else
        typeQString = rdbothers->text();

    int ID = IDQString.toInt();
    int nr = nrQString.toInt();
    float amount = amountQString.toFloat();

    std::string t = typeQString.toStdString();

    char type[100];
    std::strcpy(type,t.c_str());
    try
    {
        ctrl->add(ID,nr,amount,type);
        adaugaInLista();
        curata();
    }
   catch(Except& e)
    {
        QMessageBox::critical( this, "Eroare", "Salvarea nu s-a putut executa: " + QString::fromStdString(e.what()) );
    }
}

void MainWindow::butonModifica() {

    QString idQString = IDfield->text();
    QString IDQString = IDfield->text();
    QString nrQString = nrfield->text();
    QString amountQString = amtfield->text();
    QString typeQString;
    if (rdbgas->isChecked())
        typeQString = rdbgas->text();
    else if(rdblighting->isChecked())
        typeQString = rdblighting->text();
    else if(rdbwater->isChecked())
        typeQString = rdbwater->text();
    else if(rdbheating->isChecked())
        typeQString = rdbheating->text();
    else
        typeQString = rdbothers->text();

    //int id	 = idQString.toInt();
    int ID	 = IDQString.toInt();
    int nr	 = nrQString.toInt();

    float amount	= amountQString.toFloat();

    std::string t = typeQString.toStdString();

    char  type[100];
    std::strcpy(type,t.c_str());

    try{
        ctrl->updateController(ID,nr,amount,type);
        adaugaInLista();
        curata();
    }
    catch(Except& e){
        QMessageBox::critical( this, "Eroare", "Modificarea nu s-a putut executa: " + QString::fromStdString(e.what()) );
    }
}

void MainWindow::butonSterge() {

    QString idQString = IDfield->text();
    QString IDQString = IDfield->text();

    int ID	 = IDQString.toInt();
    try{
        ctrl->deleteController(ID);
        adaugaInLista();
        curata();
    }
    catch(Except& e){
        QMessageBox::critical( this, "Eroare", "Stergerea nu s-a putut executa: " + QString::fromStdString(e.what()) );
    }
}

void MainWindow::butonFilterAmount() {
    std::vector<DomainClass> rez;
    QString textQString = QInputDialog::getText( this, tr("Dialog"), tr("Dati suma pentru filtrare"),QLineEdit::Normal);
    float suma= textQString.toFloat();

    ctrl->filterAmountController(suma,rez);
    adaugaInLista2(rez);
}

void MainWindow::butonFilterType() {
    bool ok;
    std::vector<DomainClass> rez;

    QString textQString = QInputDialog::getText( this, tr("Dialog"), tr("Dati suma pentru filtrare"),QLineEdit::Normal, QDir::home().dirName(),&ok);
    std::string type= textQString.toStdString();
    char t[100] ;
    strcpy(t,type.c_str());

    ctrl->filterTypeController(t,rez);
    adaugaInLista2(rez);
}

void MainWindow::adaugaInLista(){
    list->clear();   // goleste lista sa o putem rescrie (nu cu append)
    std::vector<DomainClass> rez;
    rez = ctrl->getAll();
    for(unsigned  i=0; i<rez.size();i++){
        DomainClass p = rez[i];
        QString q = QString::number(p.getId())+"  "+QString::number(p.getNumber())+"  "+QString::number(p.getAmount())+"  "+QString::fromStdString(p.getType());
        new QListWidgetItem(q,list);
    }
}

void MainWindow::butonSortAmountAsc(){
    std::vector<DomainClass> rez;
    ctrl->sortAmountController(rez);
    adaugaInLista2(rez);

}

void MainWindow::butonSortAmountDesc(){
    std::vector<DomainClass> rez;
    ctrl->sortAmountControllerDesc(rez);
    adaugaInLista2(rez);

}

void MainWindow::butonSortTypeAsc(){
    std::vector<DomainClass> rez;
    ctrl->sortTypeController(rez);
    adaugaInLista2(rez);

}

void MainWindow::butonSortTypeDesc(){
    std::vector<DomainClass> rez;
    ctrl->sortTypeControllerDesc(rez);
    adaugaInLista2(rez);
}

void MainWindow::adaugaInLista2(std::vector<DomainClass> rez){
    list->clear();   // goleste lista sa o putem rescrie (nu cu append)

    for(unsigned  i=0; i<rez.size();i++){
        DomainClass p = rez[i];
        QString q = QString::number(p.getId())+"  "+QString::number(p.getNumber())+"  "+QString::number(p.getAmount())+"  "+QString::fromStdString(p.getType());
        new QListWidgetItem(q,list);
    }
}

void MainWindow::selecteazaDinLista(){
    if(list->selectedItems().count()>0){
        QString q = list->selectedItems()[0]->text();  // avem lista, selectedItems e lista eleme selectate,
                                                       //luam primul element selectat(textul din el)
        QStringList a = q.split("  ");
        IDfield->setText(a[0]);
        nrfield->setText(a[1]);
        amtfield->setText(a[2]);

        if (a[3]=="Water")
            rdbwater->click();
        else if(a[3] == "Lighting")
            rdblighting->click();
        else if(a[3] == "Gas")
            rdbgas->click();
        else if(a[3] == "Heating")
            rdbheating->click();
        else
            rdbothers->click();
    }
    else return;
}

void MainWindow::curata(){
   rdbheating->setChecked(false);
   rdbheating->setAutoExclusive(false);
   rdbwater->setChecked(false);
   rdbwater->setAutoExclusive(false);
   rdblighting->setChecked(false);
   rdblighting->setAutoExclusive(false);
   rdbgas->setChecked(false);
   rdbgas->setAutoExclusive(false);
   rdbothers->setChecked(false);
   rdbothers->setAutoExclusive(false);

   rdbothers->setAutoExclusive(true);
   //rdbgas->setAutoExclusive(true);
   //rdblighting->setAutoExclusive(true);
   //rdbheating->setAutoExclusive(true);
   //rdbwater->setAutoExclusive(true);
   IDfield->setText(false);
   nrfield->setText(false);
   amtfield->setText(false);
}

MainWindow::~MainWindow(){
    delete ui;
    delete ctrl;
}
