#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<vector>
#include<DomainClass.h>
#include<ControllerClass.h>
#include <QMainWindow>
#include<QListWidget>
#include<QPushButton>
#include<QFormLayout>
#include<QGridLayout>
#include<QHBoxLayout>
#include<QLineEdit>
#include<QLabel>
#include<QFormLayout>
#include<QRadioButton>
#include <QtGui>
#include <QInputDialog>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void construiesteFereastra();
    void butonAdaugare();
    void conectare();
    void adaugaInLista();
    void selecteazaDinLista();
    void curata();
    void butonModifica();
    void butonSterge();
    void butonFilterAmount();
    void butonFilterType();
    void adaugaInLista2(std::vector<DomainClass> );
    void butonSortAmountAsc();
    void butonSortAmountDesc();
    void butonSortTypeAsc();
    void butonSortTypeDesc();

private:
    Ui::MainWindow *ui;
    QHBoxLayout* mainLayout;
    QFormLayout* dateLayout,* filterLayout;

    QListWidget* list;

    QLineEdit* IDfield,*nrfield,*amtfield,*filterfield;
    QRadioButton *rdbwater,*rdbheating,*rdblighting,*rdbgas,*rdbothers;

    QPushButton* add,* clean,*update,* del,* filtrAmount,* filterType,*sortAmAsc,*sortAmDesc,*sortTypeAsc,*sortTypeDesc;
    ControllerClass* ctrl;
};

#endif // MAINWINDOW_H
