#pragma once
#include "DomainClass.h"
//#include "DynamicList.h"
#include <vector>
class RepositoryClass
{
public:
    RepositoryClass(void);

    void loadFromFlie(std::vector<DomainClass>  & lista);
    void saveInFile(std::vector<DomainClass>  & lista);

    ~RepositoryClass(void);
};

