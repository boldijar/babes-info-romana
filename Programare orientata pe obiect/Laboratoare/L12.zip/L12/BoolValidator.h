#pragma once
class BoolValidator
{
public:
	BoolValidator(void);
	bool validId(int);
	bool validNumar(int);
	bool validSuma(float);
	void testValidatori();
	~BoolValidator(void);
};

