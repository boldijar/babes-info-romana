/*
 * app.cpp
 *
 *  Created on: 24.03.2012
 *      Author: Florin Mihalache
 */
#include <iostream>
#include "alist.h"
#include "ui.h"

using namespace std;

int main() {
	aptList apts;
	menu(&apts);

	return 0;
}
